<?php
/*	
	file:	first.php
	Desc:	Checks if SESSION-variable $_SESSION['start'] is set. If not, creates it.
			This variable can be used in all the pages in this application.
			In PHP application means the pages in the same folder (+subfolders).
			The session object saves a cookie automatically into browser. That
			cookie is used to check that same browser is using the application.
*/
session_start();	//to access session variables.
if(!isset($_SESSION['start'])) $_SESSION['start']=date("d.m.Y - H:i:s",time());
?>
<!DOCTYPE html>
<html>
	<head><title>Session example</title></head>
	<body>
		<h3>Session example</h3>
		
		<p>Session started: <?php echo $_SESSION['start'];?></p>
		
		<p>
			<a href="start.php">Start again</a>
			<a href="second.php">Second page</a>
			<a href="third.php">Third page</a>
		</p>
		
	</body>
</html>