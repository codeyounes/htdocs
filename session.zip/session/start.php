<?php
/*
	file:	start.php
	desc:	Removes session information -> new session will be started, when user
			clicks "Start"
*/
session_start(); //use existing session, if available. Creates new if not.
session_destroy(); //removes all session variables
?>
<!DOCTYPE html>
<html>
	<head><title>Session example</title></head>
	<body>
		<h3>Session example</h3>
		
		<p><a href="first.php">Start</a></p>
		
	</body>
</html>