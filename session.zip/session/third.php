<?php
/*
	file:	third.php
	Desc:	If $_SESSION['start'] is available, displays the page. Otherwise, goes
			to start.php
*/
session_start();
if(!isset($_SESSION['start'])) header("location:start.php");
?>
<!DOCTYPE html>
<html>
	<head><title>Session example</title></head>
	<body>
		<h3>Session example</h3>
		
		<p>Session started: <?php echo $_SESSION['start'];?></p>
		
		<p>
			<a href="start.php">Start again</a>
			<a href="first.php">First page</a>
			<a href="second.php">Second page</a>
		</p>
		
	</body>
</html>